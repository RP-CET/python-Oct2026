# Import the necessary libraries
import glob    #search files that matches required patterns
import pandas as pd  #analyze data

# Define path to the csv data files
path = './Data/'

# Create list using glob to store file names starting with Product1
#     and ending with .csv
fileList = glob.glob(path + "Product1*.csv")
print (fileList)

# Create empty list to store the csv file as pandas dataframes
dfList = []

# Cycle through the files 
for file in fileList:
    
    #Read the file and convert to pandas dataframe
    data = pd.read_csv(file, encoding='utf-8')
        
    #Task 2: remove empty lines
    data.dropna(axis = 0, how='all', inplace=True)
    
    #Task 2: remove duplicates entries based on names
    data.drop_duplicates(inplace=True) 
    
    #Task 2: Identify missing cells
    data.fillna("Mising INFO", inplace=True)    
    
    #Task 3: Calculate Total Commission
    data['Revenue'] = data['Revenue'].str.replace('$', '', regex=True)
    data['Revenue'] = data['Revenue'].astype(float)
       
    data['Commission Rate'] = data['Commission Rate'].str.replace('%', '', regex=True)
    data['Commission Rate'] = data['Commission Rate'].astype(float)    
    
   #Create a new column and perform the mathematical calculations 
    data['Total Commission'] = data['Revenue']*(data['Commission Rate']/100)
    
    #append to the list of dataframes
    dfList.append(data)
    
# Merge the data in the csvList into a single pandas dataframe
csvMerged = pd.concat(dfList) 

# Convert the pandas dataframes back to csv
csvMerged.to_csv(path+ './Output/Product1_Q1_data.csv', index=False)


