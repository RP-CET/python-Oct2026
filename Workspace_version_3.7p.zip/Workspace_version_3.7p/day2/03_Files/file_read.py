# make sure you have a hello.txt in your current working directory
# same directory as your python script
helloFile = open("hello.txt")
content = helloFile.read()
print(content)
helloFile.close()

# make sure you have a hello.txt in the specified director 
# same directory as your python script
helloFile = open("hello.txt")
content2 = helloFile.readlines()
print(content2)

#prints the first line
print("first line:", content2[0])

helloFile.close()