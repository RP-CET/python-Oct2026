import shutil

# copy file, must create folder2 first
shutil.copy("folder1/hello.txt", "folder2")

# recursively copy an entire directory
# error if the destination folder already exist
#shutil.copytree("folder2", "folder2_backup")

# move file, destination folder must be an existing folder
#shutil.move("hello2.txt","folder3")

# move and/or rename file
#shutil.move("folder2/hello.txt","folder2/newhello.txt")
